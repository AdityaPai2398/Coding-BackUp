#include <iostream>

using namespace std;

void merger(int a[],int l,int h,int mid)
{
    int n1=mid+1-l;
    int n2=h-mid;
    int L[n1],R[n2];
    for(int i=0; i<n1; i++)
    {
        L[i]=a[l+i];
    }
    for(int i=0; i<n2; i++)
    {
        R[i]=a[mid+1+i];
    }
    int i=0,j=0,k=l;
    while(i<n1 && j<n2)
    {

        if(L[i]<R[j])
        {

            a[k]=L[i];
            i++;
        }
        else
        {
            a[k]=R[j];
            j++;
        }
        k++;
    } while (i < n1)
    {
        a[k] = L[i];
        i++;
        k++;
    }

    /* Copy the remaining elements of R[], if there
       are any */
    while (j < n2)
    {
        a[k] = R[j];
        j++;
        k++;
    }

}
void mergesort(int a[],int l,int h)
{
    if(l<h)
    {
        int mid=(l+h)/2;
        mergesort(a,l,mid);
        mergesort(a,mid+1,h);
        merger(a,l,h,mid);
    }

}
void printarray(int a[],int n){
for(int i=0;i<n;i++){
    cout<<a[i]<<" ";
}
}
int main()
{
    int a[]= {2,6,1,4,5};

    int n=sizeof(a)/sizeof(a[0]);
    printarray(a,n);
    cout<<"\n";
    mergesort(a,0,n-1);
    printarray(a,n);

    return 0;
}
