#include <iostream>
#include<stack>


using namespace std;

int main()
{int t;
cin>>t;
while(t--)
   {

    string s;
    cin>>s;
    int count=0;
    stack <char> myStack;
    for(int i=0;i<s.length();i++){

        if(s[i]=='(')
        {
            myStack.push(s.at(i));
        }
        if(s[i+1]==')' && s[i]=='(')
        {
            myStack.pop();
            count+=2;
        }

        }

    cout<<count<<"\n";
}
    return 0;
}
