#include <iostream>

using namespace std;
void  spiral(int m,int n,int a[3][3]){
 int k=0,l=0; //k represents counter for columns and l represents counter for the rows
 int last_row=m-1;
 int last_col=n-1;
 while(k<last_row && l < last_col){ //until their within the range of bounds of the matrix

    for(int i=l;i<=last_row;i++)
              cout<<a[k][i]<<" ";
    k++; //done with that particular row(printing from the top row)
    for(int i=k;i<=last_col;i++)
             cout<<a[i][last_col]<<" ";
    last_col--;

 }
}
int main()
{


    int a[3][3];
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
            cin>>a[i][j];

    }
    spiral(3,3,a);
    return 0;
}
