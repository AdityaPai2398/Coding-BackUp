#include <iostream>
#include<stdlib.h>
using namespace std;

struct node{
int data;
struct node *next;
};

void insert_front(struct node **head,int data){

 struct node* new_node=(struct node*)malloc(sizeof(struct node));
 new_node->data = data;
 new_node->next = *head;
 *head=new_node;
}
void insert_from_behind(struct node **head,int data){
 struct node* new_node = (struct node*)malloc(sizeof(struct node));
 new_node->data = data;
  new_node->next=NULL;
  if(*head==NULL){

    *head=new_node;
     return;
  }
  struct node *last=*head;
 while(last->next!=NULL){

    last=last->next;

 }
 last->next=new_node;

}
void print_list(struct node *head){

if(head==NULL)
    return ;
 while(head!=NULL){

    cout<<head->data<<"->";
    head=head->next;
 }

}

int main()
{
    struct node* head =NULL;
    insert_front(&head,6);
    print_list(head);
    cout<<" ";
    insert_from_behind(&head,69);
     print_list(head);
    return 0;
}
