// Efficient CPP program to find smallest
// greater element in whole array for
// every element.
#include <bits/stdc++.h>
using namespace std;

void smallestGreater(int arr[], int n)
{
	set<int> s;
	for (int i = 0; i < n; i++)
	s.insert(arr[i]);

	for (int i = 0; i < n; i++)
	{
	auto it = s.find(arr[i]);
	it++;
	if (it != s.end())
		cout << *it << " ";
	else
		cout << "_ ";
	}
}

// Driver code
int main()
{
	int ar[] = { 6, 3, 9, 8, 10, 2, 1, 15, 7 };
	int n = sizeof(ar) / sizeof(ar[0]);
	smallestGreater(ar, n);
	return 0;
}
