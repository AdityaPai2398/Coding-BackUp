#include <bits/stdc++.h>

using namespace std;

int main()
{  string crypt[3];;
   char solution[8][3];
   crypt[0]="SEND";
   crypt[1]="MORE";
   crypt[2]="MONEY";
   for(int i=0;i<8;i++)
   {
       for(int j=0;j<2;j++)
          cin>>solution[i][j];

   }
   string a=crypt[0];
   string b=crypt[1];
   string c=crypt[2];
   string num1=" ";

   for(int i=0;i<a.length();i++)
   {
         for(int j=0;j<8;i++){
            if(a[i]==solution[i][0])
                num1+=num1+solution[i][i+1];
         }
   }
   cout<<num1;
    return 0;
}
