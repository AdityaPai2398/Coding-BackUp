#include <bits/stdc++.h>

using namespace std;

int main()
{
    string s[]={"abcfdf","bc"};
    cout<<s[0].length();
    return 0;
}
