#include <iostream>

using namespace std;
void swap(int *a,int *b){

int temp;
temp=*a;
*a=*b;
*b=temp;
}
int partition(int a[],int low,int high){
   int i =low-1;
   int pivot=a[high];
   for(int j=low;j<=high;j++){

    if(a[j]<=pivot){
        i++;
        swap(&a[i],&a[j]);
        }

   }
   swap(a[i-1],pivot);

   return (i+1);
}
void quicksort(int a[],int low,int high){
  if(low<high){
    int p =partition(a,low,high);
    quicksort(a,low,p-1);
    quicksort(a,p+1,high);

  }
}
void printarray(int a[],int n){
for(int i=0;i<n;i++)
    cout<<a[i]<<" ";
}
int main()
{
    int a[]={23,1,5,7,8};
    int n=sizeof(a)/sizeof(a[0]);
    printarray(a, n);
    cout<<"\n";
    quicksort(a,0,n-1);
    printarray(a,n);
    return 0;
}
