#include <bits/stdc++.h>

using namespace std;

int main()
{
    string s;
    cin>>s;
    int len=s.length()-1;
    for(int i=0;i<=s.length()/2;i++){
        if(s[i]!=s[len])
        {
          cout<<"Not";
exit(0);
        }
        len--;
    }
    cout<<"ye";

}
