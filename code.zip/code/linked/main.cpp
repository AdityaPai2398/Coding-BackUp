
#include<bits/stdc++.h>
using namespace std;


struct node{

int data;
struct node *next;
};
void insert(struct node **head,int data)
{

    struct node *temp = (struct node*)malloc(sizeof(struct node));
    temp->data=data;
    temp->next=*head;
    *head=temp;
}
void printList(struct node *head){

struct node *temp = head;
while(temp!=NULL)
      {
        cout<<temp->data<<"\t";
       temp=temp->next;
      }
}
int countList(struct node *head){
int count=0;
struct node *temp = head;
while(temp!=NULL)
      {
        count++;
        temp=temp->next;
      }
      return count;
}

void printReverse(struct node *head){
struct node *temp=head;
if(temp==NULL)
     return;

printReverse(temp->next);
cout<<temp->data<<"\t";
}
int main()
{
    struct node *head=NULL;
    insert(&head,5);
    insert(&head,7);
    insert(&head,8);
    insert(&head,5);
    insert(&head,7);
    insert(&head,8);
    printList(head);
    int c=countList(head);
    cout<<"\nCount of elements is "<<c;
    cout<<"\nReverse Linked List is ";
    printReverse(head);
    cout<<"\n";
            printList(head);
    return 0;
}
