#include <iostream>

using namespace std;
void bubblesort(int a[],int n ){

      for(int i=0;i<n-1;i++){

        for(int j=0;j<n-i-1;j++){

            if(a[j]>a[j+1]){

                int temp = a[j+1];
                a[j+1]=a[j];
                a[j]=temp;
            }
        }
      }

         for(int i=0;i<n;i++)
           cout<<a[i]<<" ";

}

int main()
{
    int a[]={23,12,3,4,5,8,156,-89,45,123,421};
    int n = sizeof(a)/sizeof(a[0]);
    for(int i=0;i<n;i++)
         cout<<a[i]<<" ";

         cout<<endl;
    bubblesort(a,n);
    cout<<endl<<endl;

      for(int i=0;i<n;i++)
           cout<<a[i]<<" ";


    return 0;
}
