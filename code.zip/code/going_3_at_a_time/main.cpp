#include <iostream>

using namespace std;

int main()
{
  gridar grid[9][9];
  for(int i=0;i<9;i++)
  {
      for(int j=0;j<9;j++){
        cin>>grid[i][j];
      }

  }
  int i,j,k;
  int count[9]={0};
  int res1=0,res2=3,t;
  for( k=0;k<3;k++)
  {

   for( i=res1;i<res2;i++){

    for( j=0;j<3;j++){

       if(grid[i][j]!='.'){
        if(count[grid[i][j]-'1']==0)
        {
            count[ch[i][j]-'1']++;
        }
        else
        {
            return false;
        }
        }
    }
   t=i;
  }
    for(int i=0;i<9;i++)
         count[i]=0;
    res1=++t;
    res2+=3;

    if(res2>9)
        break;
    }

  for(int i=0;i<9;i++)
         count[i]=0
 for( k=0;k<3;k++)
  {

   for( i=res1;i<res2;i++){

    for( j=3;j<6;j++){

       if(ch[i][j]!='.'){
        if(count[grid[i][j]-'1']==0)
        {
            count[grid[i][j]-'1']++;
        }
        else
        {
            return false;
        }
        }
    }
   t=i;
  }
    for(int i=0;i<9;i++)
         count[i]=0
    res1=++t;
    res2+=3;

    if(res2>9)
        break;
    }

  for(int i=0;i<9;i++)
         count[i]=0
  res1=0,res2=3;
  for( k=0;k<3;k++)
  {

   for( i=res1;i<res2;i++){

    for( j=6;j<9;j++){

       if(grid[i][j]!='.'){
        if(count[grid[i][j]-'1']==0)
        {
            count[grid[i][j]-'1']++;
        }
        else
        {
            return false;
        }
        }
    }
   t=i;
  }
    for(int i=0;i<9;i++)
         count[i]=0
    res1=++t;
    res2+=3;

    if(res2>9)
        break;
    }
    return 0;
}
