#include <iostream>

using namespace std;

struct node{

int data;
struct node *next;
};
void push(struct node **head,int data){

struct new_node=(struct node*) new malloc(sizeof(struct node));
new_node->data=data;
new_node->next=*head;
*head=new_node;
}
void printdata(struct node *head){

struct node temp = head;
while(temp!=NULL){
        print(temp->data)'

}}
int main()
{
    struct node head=NULL;
    push(&head,5);
    return 0;
}
