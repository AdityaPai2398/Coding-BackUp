#include <iostream>

using namespace std;

void find_d(int arr[],int n){
   sort(arr,arr+n);
   for(int i=n-1;i>=0;i--){
     for(int j=0;j<n;j++){

        if(i==j)
            continue;
        for(int k=i+1;k<n;k++)
         {

         if(j==k)
               continue;
        for(int l=k+!;l<n;l++)
            if(l==k)
             continue;
            if(arr[i]=arr[j]+arr[k]+arr[l])
            {
                found = true;
                return arr[i];
            }

     }}
   }
}
int main()
{
    int arr[]={23,56,78,90,79};
    int n = sizeof(arr)/sizeof(arr[0]);
    find_d(arr,n);
    return 0;
}
