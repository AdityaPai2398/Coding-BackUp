
#include<bits/stdc++.h>
using namespace std;

int main()
{
    int a[]={23,54,1,2,-98,34,2,3,32,24,2,2,244,2,-1};
    int n=sizeof(a)/sizeof(a[0]);
   /* int x=10, y=20;                              // x:10 y:20
    swap(x,y);
    cout<<x<<" "<<y<<endl;
    */
    for(int i =1;i<n;i++){
        int key=a[i];
        int j=i-1;
        while(j>=0 && a[j]>key){

            a[j+1]=a[j];
            j--;
        }

      a[j+1]=key;
    }
    for(int i=0;i<n;i++)
        cout<<a[i]<<" ";
    return 0;
}
