#include <bits/stdc++.h>

using namespace std;

int main()
{
char c[9][9];
  for(int i=0;i<9;i++)
  {
      for(int j=0;j<9;j++){
        cin>>c[i][j];
      }

  }
  int count[9]={0};
  int res1=0,res3=0;
  int res2=3,res4=3;
  for(int k=0;k<3;k++){
        cout<<"k="<<k<<endl;
       for(int i=res1;i<res2;i++)
       {cout<<"i="<<i<<endl;

           for(int j=res3;j<res4;j++){
                 cout<<"j="<<j<<endl;
                 if(c[i][j]!='.')
                 { cout<<"When its not a fucking ."<<endl;
                     if(count[c[i][j]-'1']==0)
                        {
                         count[c[i][j]-'1']++;
                         cout<<"found char and incremented that shit";
                         cout<<count[c[i][j]-'1']<<" _";
                         }
                     else
                     {   cout<<"That char shit was already counted";
                         cout<<"false";

                     }
                 }
                  if(j==2 || j==5)
                {
                cout<<"came into the next sub section";
                   res3++;
                   res4+=3;
                   if(res4>9)
                        res4=0;
                   count[9]={0};
                   }
           }

       }


       res1+=3;
       res2+=3;
       if(res2>9)
        {
         cout<<"Eceeded the fucking bounds";
         break;}
  }
    return 0;
}
