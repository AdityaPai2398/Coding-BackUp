#include <iostream>

using namespace std;

int binary_search(int a[],int key,int low,int high){
    int mid = low+(high-low)/2;
    if(high>=low){
    if(key==a[mid])
        return mid;
    else if(key>a[mid])
        return binary_search(a,key,mid+1,high);
    else
        return binary_search(a,key,low,mid-1);
    }
    return -1;
}
int main()
{
    int a[]={23,45,67,88,92,107};
    int key= 12;
    int n=sizeof(a)/sizeof(a[0]);
    int ele = binary_search(a,key,0,n-1);
    if(ele!=-1){

        cout<<"Element "<<key<<"found at index "<<ele;
    }
    else{ cout<<"Element not found";}
    return 0;
}
