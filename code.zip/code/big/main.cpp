#include <iostream>
#include<boost/multiprecision/cpp_int.hpp>

namespace mp= boost::multiprecison;
using namespace std;

int main()
{   mp::cpp_int a=1;
     int n;
     cin>>n;
     for(int i =0;i<n;i++)
        a=a*i;
      cout<<a;

    return 0;
}
