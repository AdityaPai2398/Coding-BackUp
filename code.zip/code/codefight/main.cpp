#include <iostream>

using namespace std;

int main()
{
    int i,j,k;
  char grid[9][9];
  for(int i=0;i<9;i++)
  {
      for(int j=0;j<9;j++){
        cin>>grid[i][j];
      }

  }
  int count1[9]={0},count2[9]={0};
  int res1=0,res2=3,t;
  for( k=0;k<3;k++)
  {

   for( i=res1;i<res2;i++){

    for( j=0;j<3;j++){

       if(grid[i][j]!='.'){
        if(count[grid[i][j]-'1']==0)
        {
            count[grid[i][j]-'1']++;
        }
        else
        {
            cout<<"false";
        }
        }
    }
     for(int l=0;l<3;l++){

       if(grid[i][l]!='.'){
        if(count2[grid[i][l]-'1']==0)
        {
            count3[grid[i][l]-'1']++;
        }
        else
        {
            cout<<"false";
        }
        }
    }
   t=i;
  }
    for(int i=0;i<9;i++)
         count[i]=0;
    res1=++t;
    res2+=3;

    if(res2>9)
        break;
    }

        for(int i=0;i<9;i++)
    {
        for(int j=0;j<9;j++)
        {
           if(grid[i][j]!='.')
           {
               char ch=grid[i][j];

               int i_idx=i;
               int j_idx=j;
               for(int i=i_idx+1;i<9;i++)
               {
                   if(i_idx%3==0)
                   {
                          if(grid[i][j_idx]==ch)
                           {
                               cout<<"false" ;
                           }
                   }
               }
               for(int j=j_idx+1;j<9;j++)
               {
                         if(grid[i_idx][j]==ch)
                         {
                            cout<<"false";
                         }

               }
           }
        }
    }

}
