#include <iostream>

using namespace std;

int main()
{
  char ch[9][9];
  for(int i=0;i<9;i++)
  {
      for(int j=0;j<9;j++){
        cin>>ch[i][j];
      }

  }
  int i,j,k;
  int count[9]={0};
  int res1=0,res2=3,t;
   for( k=0;k<3;k++)
  {cout<<"k-->"<<k<<endl;
   for( i=res1;i<res2;i++){
        cout<<"i--->"<<i<<endl;
    for( j=0;j<3;j++){
        cout<<"j-->"<<j<<endl;
       if(ch[i][j]!='.'){
        if(count[ch[i][j]-'1']==0)
        {
            count[ch[i][j]-'1']++;
        }
        else
        {
            cout<<"false"<<endl;
            cout<<endl<<"count is"<<count[ch[i][j]-'1']<<endl;
        }
        }
    }
   t=i;
  }
    for(int i =0;i<9;i++)
    {
        count[i]=0;
    }
    res1=++t;
    res2+=3;
    cout<<"Final values"<<i<<" "<<j<<" "<<k<<" "<<res1<<" "<<res2;
    if(res2>9)
        break;
    }
   cout<<endl<<"Second section"<<endl;
  count[9]={0};
  res1=0,res2=3;
 for( k=0;k<3;k++)
  {cout<<"k-->"<<k<<endl;
   for( i=res1;i<res2;i++){
        cout<<"i--->"<<i<<endl;
    for( j=3;j<6;j++){
        cout<<"j-->"<<j<<endl;
       if(ch[i][j]!='.'){
        if(count[ch[i][j]-'1']==0)
        {
            count[ch[i][j]-'1']++;
        }
        else
        {
            cout<<"false"<<endl;
        }
        }
    }
   t=i;
  }
    count[9]={0};
    res1=++t;
    res2+=3;
    cout<<"Final values"<<i<<" "<<j<<" "<<k<<" "<<res1<<" "<<res2;
    if(res2>9)
        break;
    }
  cout<<"Third section"<<endl<<endl;
  count[9]={0};
   res1=0,res2=3;
   for( k=0;k<3;k++)
  {cout<<"k-->"<<k<<endl;
   for( i=res1;i<res2;i++){
        cout<<"i-->"<<i<<endl;
    for( j=6;j<9;j++){
        cout<<"j-->"<<j<<endl;
       if(ch[i][j]!='.'){
        if(count[ch[i][j]-'1']==0)
        {
            count[ch[i][j]-'1']++;
        }
        else
        {
            cout<<"false"<<endl;
        }
        }
    }
   t=i;
  }
    count[9]={0};
    res1=++t;
    res2+=3;
    cout<<"Final values"<<i<<" "<<j<<" "<<k<<" "<<res1<<" "<<res2;
    if(res2>9)
        break;
    }
    return 0;
}
