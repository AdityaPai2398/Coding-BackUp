#include <iostream>

using namespace std;

int main()
{
    int a[]={22,44,666,777,888,998};
    int key=999;
    int mid;
    int n = sizeof(a)/sizeof(a[0]);
    int low=0;
    int high=n-1;
    int index=-1;
    while(low<=high){

        mid = low + (high-low)/2;

        if(key==a[mid])
        {
            index=mid;
            break;
        }
        else if(key<a[mid])
            high = mid -1;
        else
            low = mid+1;

    }
    //Auxiliary Space: O(1) in case of iterative implementation. In case of recursive implementation, O(Logn) recursion call stack space.
    if(index!=-1)
       cout<<"Element found at index"<<index;
   else
        cout<<"Element not found";
    return 0;
}
