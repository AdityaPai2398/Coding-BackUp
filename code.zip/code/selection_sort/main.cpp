#include <iostream>

using namespace std;
void swap(int *x,int *y){


int temp=*x;
*x=*y;
*y=temp;
}
int main()
{
    int a[]={89,12,34,2,23,34,35,0,-223,2,-23};
    int n = sizeof(a)/sizeof(a[0]);
    int min_idx;
    for(int i = 0 ;i < n - 1; i++){

        min_idx=i;
        for(int j = i +1;j<n;j++){

            if(a[j]<a[min_idx])
            {
                min_idx=j;
            }
        }
        swap(a[i],a[min_idx]);
    }
    for(int i = 0;i<n;i++){

        cout<<a[i]<< " ";
    }
    return 0;
}
