#include <iostream>
#include<string.h>
using namespace std;


string compute(string prefix,string temp){
  int n1  = prefix.length();
  int n2  = temp.length();
  string result;
  for(int i=0,j=0;i<n1 && j<n2;i++,j++){

    if(prefix[i]!=temp[j])
        break;
    else
        result.push_back(prefix[i]);


  }
  return result;

}
string find_prefix(string s[],int n){
    string prefix = s[0];
    for(int i=1;i<n;i++)
         prefix = compute(prefix,s[i]);

    return prefix;

///

}
int main()
{


    int n;
    cin>>n;
    string s[n];
    for(int i=0;i<n;i++)
        cin>>s[i];
    string result  = find_prefix(s,n);
    if(result.length())
         cout<<result.c_str();
    else
        cout<<"no prefix";
    return 0;
}
