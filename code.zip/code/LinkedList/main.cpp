
#include<bits/stdc++.h>
using namespace std;

struct node{
int data;
struct node *next;
};

int main()
{
    struct node* new_node= (node*)malloc(sizeof(struct node));
    new_node->data=5;
    new_node->next=NULL;
    struct node* new_node2= (node*)malloc(sizeof(struct node));
    new_node2->data=7;
    new_node->next=new_node2;
    struct node* new_node3= (node*)malloc(sizeof(struct node));
    new_node3->data=8;
    new_node2->next=new_node3;
    struct node* new_node4= (node*)malloc(sizeof(struct node));
    new_node4->data=9;
    new_node3->next=new_node4;
    new_node4->next=NULL;
    struct node *temp=new_node;
    while(temp!=NULL)
    {
        cout<<temp->data<<" ";
        temp=temp->next;
    }
    int key;
    cin>>key;
    temp=new_node;
    struct node *front;
    while(temp!=NULL){
        front=temp->next;
        if(front->data == key)
        {
            temp->next=temp->next->next;
            free(front);

        }
        temp=temp->next;

    }
    temp=new_node;
    while(temp!=NULL)
    {
        cout<<temp->data<<" ";
        temp=temp->next;
    }

        return 0;
}
