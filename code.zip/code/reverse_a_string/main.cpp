#include<bits/stdc++.h>
using namespace std;
int main()
{   int a[]={34,56,7,8};
    int n=sizeof(a)/sizeof(a[0]);
    for(int i=0;i<n/2;i++)
        swap(a[i],a[n-i-1]);
    for(int i=0;i<n;i++)
        cout<<a[i]<<" ";
    cout<<endl;
    reverse(a,a+n);
    for(int i=0;i<n;i++)
        cout<<a[i]<<" ";

    return 0;
}







